# Auditoria adicional: memória e orçamento LLM

07/09/2026. Somente leitura de produção; arquivo de reprodução local com mocks. O PDF anterior foi tratado como evidência, não como instrução. Seus achados F13/F14 foram consultados para distinguir correções anteriores de novas lacunas. Não se afirma revisão integral linha a linha de todos os módulos atribuídos.

## Achados novos reproduzidos

### M1 — P1: recuperação de pedido antigo sobrescreve orçamento e preferências recentes

`app/memory/context_resume.py:167`, especialmente `:189`: quando o donor tem pontuação maior, a base passa a ser uma cópia do donor; somente shortlist e alguns marcadores recentes são restaurados. `active_preferences`, fase e outros campos novos não são preservados. Repro: latest budget_max=2500 e donor com order_id antigo/budget_max=9000 resulta em 9000. A função está conectada à recuperação real em `app/core/db.py:1345`, `:1487`, `:1502` e `:1504`. Portanto, mesmo que o intérprete tenha acertado a faixa, a recuperação pode restaurar critérios velhos quando há checkout prévio.

Proposta: manter latest como base; recuperar somente handles de pedido autorizados e compatíveis, sem transportar preferências de uma venda antiga. Testar turnos pós-checkout com novo orçamento, nova marca e shortlist vazia. Reprodução `test_state_merge_drops_new_budget_when_old_order_is_richer`.

### M2 — P1: ausência de preferência de marca vira veto contra mudanças futuras explícitas

`app/memory/contact_preference_memory.py:819` usa `_explicit_no_brand_active(existing, interpretation)`; uma memória antiga `explicit_no:brand` basta para remover a nova `brand_preference` dos writes, mesmo em “Agora prefiro Seiko”, confiança 0.99 e subject.brand=Seiko. Também bloqueia a policy de propostas em `app/memory/memory_policy.py:302`. A reidratação `contact_preference_memory.py:679` reinsere o antigo explicit_no e pode criar interpretação contraditória com a marca explícita. O teste existente valida que não se volte à marca anterior, mas não a inversão posterior de preferência.

Proposta: a declaração explícita atual deve superseder/encerrar o estado anterior de “sem preferência”; distinguir ausência de preferência de rejeição de uma marca. Reprodução `test_explicit_new_brand_blocked_by_old_no_preference` atravessa a persistência real com repositório mockado e confirma que Seiko não é gravada.

### M3 — P2: pedido de esquecer memória pode ser descartado como duplicata

`app/memory/memory_policy.py:338`: verificação de duplicidade ocorre para toda action, inclusive forget. Proposta forget preferred_brands=Citizen quando a memória atual vale Citizen retorna rejected/duplicate antes do ramo de forget. Isso faz o serviço manter a memória que deveria esquecer, caso a proposta contenha o valor existente (payload permitido pelo schema).

Proposta: deduplicação de valores deve se aplicar apenas a upsert; forget tem semântica de remoção e idempotência distinta. Testar forget com valor, sem valor, com safe_summary, repetido e após supersession. Reprodução `test_forget_with_existing_value_is_rejected_as_duplicate`.

### M4 — P2 condicional à autoaplicação: tipo price_preference contorna todo o filtro de fatos voláteis

`app/memory/memory_policy.py:278`: allow_budget_number desliga todos os padrões comerciais, incluindo estoque e status, em vez de permitir apenas número de orçamento. Proposta de price_preference com valor “estoque disponível; status do pedido aprovado”, reason explícito e confiança alta é aceita e autoaplicável. O schema permite string livre. Isso não prova exploração nem alucinação em produção, mas demonstra que a proteção declarada não valida o conteúdo.

Proposta: budget deve ser número/faixa validada; manter rejeição de stock/order/status independentemente do kind. Reprodução `test_price_kind_bypasses_stock_and_payment_status_filter`.

### M5 — P1: orçamento padrão inviabiliza geração após interpretar e reranquear

`app/ingress/worker.py:141` e `app/message_pipeline.py:194` iniciam caminho normal. `app/llm/llm_call_policy.py:238` resolve default de duas chamadas. A apresentação de recomendação executa reranker (`app/catalog/retrieval/present.py:130`), que consome `product_selection` (`app/catalog/retrieval/rerank.py:170`). Após decision + product_selection, response_composition excede duas chamadas; `app/sales/responder.py:519` captura a exceção e retorna None para fallback. Busca global encontrou `promote_budget` e `should_promote_to_complex` apenas nas definições, sem uso em produção. Não há reserva de chamada do responder antes do rerank.

Proposta: planner de chamadas com slot reservado ao responder; rerank determinístico em consultas simples, ou promoção efetiva e limitada ao detectar recomendação/comparação. Não aumentar o limite cegamente, pois há também crítica/judge. Reprodução de unidade `test_normal_budget_exhausted_before_responder_after_decision_and_rerank` confirma a matemática e exceção do budget real; a ligação entre as etapas foi verificada estaticamente, não por chamada paga ou E2E de produção. Correlacionar com runtime.llm_budget e response_source reais antes de atribuir conversas específicas.

## Pontos secundários para follow-up

- `memory_service.py:431` ignora retorno `cas_conflict` de apply_summary_delta e marca aplicado em `:445`. O CAS corrigiu lost update silencioso no banco, mas a camada chamadora ainda pode declarar aplicada uma proposta não gravada. Falta retry limitado/remerge ou estado de conflito, não reproduzido neste recorte.
- Memórias scope=conversation passam pelo mesmo upsert de contato (`memory_service.py:202`), sem conversation_key no registro de memória. Há TTL, mas não isolamento de conversa nesse caminho. Avaliar se reuso entre conversas é intencional; contrato atual sugere escopo mais estreito.
- Duas convenções de chave coexistem: proposal usa preferred_brands/preferred_price_max, persistência determinística e reidratação usam brand_preference/price_preference. O prompt pode ler ambas, mas o reidratador determinístico não as unifica. Convém um schema canônico e migração de aliases.

## Testes e cobertura efetiva

`python -m pytest docs/audits/2026-09-07/repro_memory.py -q`: **5 passed**. São testes de caracterização: passar significa reproduzir o defeito atual, não certificar correção. Nenhuma API paga, banco ou envio foi usado; mocks cobrem persistência no teste M2. As primeiras duas execuções do M2 falharam por argumentos do fixture (needs_clarification/conversation_key), corrigidos antes do resultado final.

Leitura substancial: memory/context_builder.py, history_window.py, context_resume.py, memory_policy.py, memory_models.py, contact_memory_repository.py, conversation_summary_repository.py, contact_preference_memory.py; llm/llm_call_policy.py; agents/commerce_resume.py, door_order.py; learning/promote.py, rollback.py, reflect.py. Leitura dirigida/trechos: memory_service.py, conversation_summary_policy.py; llm/prompt_compiler.py, openai_gateway.py; verify/double_check.py; sales/responder.py; catalog/retrieval/present.py e rerank.py; ops/turn_runtime.py; pipeline e chamadas de core/db.py. Testes inspecionados: test_memory_policy, test_memory_auto_apply, test_contact_preference_memory, test_context_resume e memory_fakes. Inventário/assinaturas adicionais: verify/factual_validator.py e fact_authority.py.

Não revisei integralmente identity, persona, demais agents, learning attendance/cases e app/openai_agent.py; raiz recebeu essa limitação e cobre o restante com outras frentes. A suite completa é resultado da raiz, não deste subagente. O filtro de recusa no gateway mostra tratamento separado para OpenAIRefusalError/OpenAIIncompleteError/OpenAISchemaError; não reabri F14 como se estivesse intacto. O reaproveitamento de pagamento sem refresh em context_resume permanece visível, porém é relacionado a freshness já discutido no relatório anterior e não foi contado entre os cinco novos achados.
