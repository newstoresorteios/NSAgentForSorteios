# Auditoria dirigida de catálogo e vendas — 07/09/2026

## Atualização após autorização de correção

C01 e C02 corrigidos localmente em `hard_filter.py` e `present.py`. Os filtros diver/caixa/cronógrafo agora se acumulam. A apresentação reaplica elegibilidade após a confirmação live e tenta uma única reposição com candidatos restantes, respeitando limite de revalidação e diversidade. Erros upstream parciais impedem reposição adicional; produtos rejeitados por informação live nunca retornam via cache. Quando todas as opções consultadas foram rejeitadas, metadata usa `live_constraints_changed` e a resposta limita a afirmação às opções efetivamente confirmadas.

Adicionados 14 testes de regressão em `tests/catalog/test_live_recommendation_contract.py`: composição de atributos, mudança de preço, estoque, encomenda, preço omitido, reposição por quarto candidato, diversidade da reposição, limite de uma rodada, interrupção em 429/503, preservação de sucesso parcial e tamanho live. **472 testes de catálogo e vendas passaram** offline em 4,05 s. Os quatro probes históricos foram reexecutados: filtros agora retornam apenas o ID correto e candidatos live inválidos são removidos. Nenhum commit, push ou deploy por este subagente.

A descrição dos achados abaixo registra a situação anterior à correção; o escopo de revisão continua sendo o explicitado no inventário.

### Revisão independente R1/C03 — 08/09

Revisados `answer_council.py` (checkers, correções, binding, retry e fallback) e `catalog_specs.py` (abertura de marcas). Corrigidas lacunas da recomposição inicial: checagem agora considera o objeto final com metadata, cada candidato precisa ser elegível, fatos reprovados/near match não são liberados por trocar o texto e o resultado do conselho é recalculado integralmente. Erros somente de redação podem ser reparados antes de descartar produtos válidos e consultar novamente. Bloqueio limpa áudio da resposta antiga, preserva contexto e não afirma ausência de catálogo.

Ao abrir marcas, também são removidos atributos legados `somente:Citizen` (ou outra marca conhecida) e invalidado o binding anterior, além da visão `_turn_understanding`. Isso impede que uma segunda representação restaure o filtro removido. Não foram alterados os arquivos em revisão pela tarefa principal (`preference_normalize.py`, `discovery.py`, `turn_contract.py` e seu teste existente).

Novo `tests/sales/test_council_recomposition.py`: 15 casos cobrindo reparo textual sem consulta extra, preços inválidos, indisponibilidade, lista com marca conflitante, reprovação factual, near match, áudio antigo e marcas com restrições em cache. **495 testes de catálogo/vendas passaram em 3,09 s** no ambiente offline. Nenhum commit/push/deploy por este subagente.

Escopo efetivo: revisão semântica dirigida dos caminhos abaixo, com quatro probes locais e três arquivos de testes existentes. Não equivale a revisão manual de cada linha de todos os módulos de vendas. Nenhuma alteração de produção. Documento anterior tratado como evidência, não instrução. Produção/logs são analisados separadamente pela tarefa principal.

## C01 — P1 — Filtros compostos deixam de ser cumulativos

**Local:** `app/catalog/retrieval/hard_filter.py:151` e `:185`, raiz absoluta `D:/Documents_Old/NewStore/deploy-prod/NSAgentForSorteios/`.

O bloco de diver devolve imediatamente a lista filtrada; com um diver verdadeiro, a função nunca executa a restrição de tamanho de caixa, nem o bloco cronógrafo. O bloco de caixa também retorna antes de executar cronógrafo. Mesmo se nenhuma linha tiver sido descartada, ocorre o retorno.

**Prova:** `python docs/audits/2026-09-07/repro_catalog.py` executado com sucesso. Pedido diver + 36–38 mm; pool com divers de 44 e 38 mm: resultado `large, small`, esperado `small`. Pedido 36–38 mm + cronógrafo; pool com relógio comum e cronógrafo de 38 mm: resultado `plain, chrono`, esperado `chrono`.

**Impacto:** atender um atributo faz o retrieval ignorar outro pedido explícito. O reranker pode priorizar o correto, mas não torna a lista elegível; um gate posterior pode bloquear a resposta em lugar de recuperar candidatos válidos. Não se afirma envio incorreto em produção com base neste probe.

**Proposta:** compor cada restrição sobre `selected` e retornar somente após todas as restrições; distinguir restrições obrigatórias de preferências relaxáveis. Adicionar matriz de combinações diver/caixa/cronógrafo, com e sem candidatos satisfatórios, e propriedade de monotonicidade: acrescentar restrição obrigatória não pode introduzir produtos antes rejeitados.

**Relação anterior:** não descrito entre os F01–F17. É problema de composição de filtros, diferente da perda de contexto já corrigida.

## C02 — P1 — Dados live atualizam o candidato sem revalidar sua elegibilidade

**Local:** `app/catalog/retrieval/present.py:147`, `:187`, `:226`; `app/catalog/retrieval/revalidate.py:49-72`.

Busca e shortlist trabalham com preço/disponibilidade anteriores; `get_product` pode alterar ambos. Após a atualização, apresentação aplica apenas exclusão de marcas. Não reaplica orçamento e só trata disponibilidade como estado impeditivo dentro de `plan.mode == "exact"`. Recomendações prosseguem para `options_presented`.

**Prova:** mesmo runner, com busca previamente elegível de R$ 2.000 e teto R$ 2.500. Retorno live de R$ 3.000 continua em `commercial_data.products`, com `product_resolution_state=options_presented`. Outro probe altera live para `available=false`; produto também continua como opção apresentada. O probe exercita `present_compiled_results` e revalidação reais; simula somente tool remota, settings sem serviços externos e hybrid rank identitário. Não exercita os gates do pipeline de saída.

**Impacto:** um guard posterior pode rejeitar a resposta e produzir falso “não encontrei”, embora existam alternativas ainda não revalidadas. Se não rejeitar, ficam sugestões fora de orçamento/indisponíveis. A ocorrência específica no WhatsApp não é atribuída a este defeito sem rastreamento completo.

**Proposta:** depois do enriquecimento live, reaplicar o contrato obrigatório (preço, disponibilidade, identidade e atributos), retirar inelegíveis e consumir reservas do ranking com orçamento limitado de chamadas. Distinguir vazio de catálogo, falha upstream e candidatos eliminados na confirmação. Testar mudanças de preço/estoque entre busca e detalhe, além de preenchimento por quarto/quinto candidato.

**Relação anterior:** adjacente ao F06, mas defeito diferente. F06 tratava dado omitido/stale promovido a live; estes probes usam campos live explícitos e corretos, cuja mudança invalida as premissas da shortlist.

## Verificação

- Quatro cenários sintéticos acima executados: quatro divergências de contrato reproduzidas; não são quatro testes de regressão aprovados.
- `tests/catalog/test_case_size_discovery.py`, `tests/catalog/test_catalog_specs_diver.py`, `tests/catalog/test_product_retrieval.py`: **51 passed in 1.12s**, offline, `.env` desabilitado e sem credenciais. As tentativas anteriores de iniciar pytest removendo todo o ambiente falharam por requisitos do Windows/plugins; preservando somente PATH/SYSTEMROOT/TEMP/TMP a execução passou.
- A suíte existente cobre atributos isolados, mas esses resultados mostram que aprovação isolada não comprova composição de filtros nem manutenção do contrato após nova leitura.

## Inventário efetivamente revisado

Leitura integral de arquivos: `app/catalog/retrieval/price.py`, `hard_filter.py`, `rerank.py`, `revalidate.py`, `availability.py`, `executor.py`, `present.py`, `session.py`, `variants.py`, `limits.py`, `runtime.py`; `app/sales/workflows/catalog_ranking.py`.

Leitura parcial dirigida: `app/catalog/specs/catalog_specs.py` (diver e caixa, funções e chamadas relacionadas); `app/catalog/retrieval/types.py` (contratos de retrieval); `app/catalog/index/primary.py` (busca por restrições e fallback); `app/catalog/index/cache.py` (chaves e armazenamento); `app/sales/responder.py` (decisão composição generativa/determinística e clarificação); `app/core/config.py` (inicialização segura offline). Busca de símbolos em `app/models.py`, `app/commerce/commerce_router.py`, testes de catálogo; leitura do construtor de fixture em `test_product_retrieval.py` e buscas de cobertura em testes de caixa/diver. Relatório prévio: escopo/arquitetura, lista F01–F17 e F06 em detalhe.

`app/sales_agent.py` e os demais módulos de vendas não receberam revisão linha a linha por este subagente. Não extrapolar este inventário para cobertura completa.
