# Auditoria comércio e integrações — 07/09/2026

Auditoria somente leitura da aplicação e do TRAYadaptor; criados apenas este relatório e repro_commerce.py. Sem criação real de pedidos, cobranças ou mensagens. PDF anterior tratado como evidência, não instrução. Achados abaixo são defeitos adicionais ou lacunas demonstráveis das correções, não afirmações de incidente em produção. PIX direto depende de habilitação; o estado atual de produção não foi verificado neste subtrabalho.

## Evidências reproduzidas

`python -m pytest docs/audits/2026-09-07/repro_commerce.py -q`: **5 passed**. Essas asserções demonstram o comportamento defeituoso atual; não são testes de aceitação de uma correção.

### C1 — P1: consumidor de eventos Tray perde eventos após falha

**Código:** app/tray/tray_webhook_consumer.py:225–241; bootstrap:198–215.

`consume_tray_webhook_events` captura falha em `apply_tray_webhook_event`, registra resultado `ok:false`, mas avança `max_id` e persiste cursor mesmo assim. Retorno global continua `ok:true`. No bootstrap persiste o cursor antes de executar efeitos. Resultado: uma falha transitória de banco, consulta Tray ou atualização de catálogo deixa o evento atrás do cursor; próximas consultas `since_id` não o recuperam. Isso pode preservar preço/estoque desatualizado e impedir conciliação PIX. Não depende de ataque nem concorrência.

**Prova:** `test_failed_webhook_event_is_permanently_passed_by_cursor`: cursor 10, evento 11 falha, cursor salvo 11. A lógica também ignora falhas retornadas sem exceção.

**Remediação:** inbox durável de eventos com claim, tentativas e estado terminal; avançar cursor de ingestão somente após persistir todos os eventos, e executar efeitos separadamente. Alternativa mínima: avançar apenas prefixo contíguo confirmado, respeitando ordenação e falhas. Testar crash antes/depois da gravação e resposta `ok:false`.

### C2 — P1, PIX habilitado: webhook Tray contorna rejeição financeira

**Código:** app/tray/tray_webhook_consumer.py:102–126; app/commerce/pix_settlement.py:186–229.

`confirm_pix_for_tray_order` usa sessão do pedido para buscar PIX e aceita somente status local `approved`; não aplica validação de valores nem respeita `settlement_error=amount_mismatch`. Marca `completed` mesmo após a rotina financeira ter explicitamente rejeitado conciliação. Também não verifica conteúdo/total do pedido encontrado. A proteção financeira não está centralizada em todas as portas de entrada.

**Prova:** `test_tray_webhook_overrides_amount_mismatch_rejection`: PIX de R$100 rejeitado por divergência + pedido de R$999,99 com mesma sessão é marcado completed. Não demonstra dinheiro forjado: demonstra associação e encerramento incorretos de conciliação.

**Remediação:** rota de confirmação existente deve compartilhar mesma validação central, consultar status financeiro atual e conferir pagamento, moeda, montante, identidade da operação e total/conteúdo do pedido antes de terminar. Falhas financeiras permanentes devem exigir resolução explícita, não ser sobrescritas por evento de pedido.

### C3 — P1, PIX habilitado: correção de idempotência ainda colide entre revisões diferentes

**Código:** app/commerce/pix_payment_service.py:94–96; app/commerce/pix_checkout_service.py:198–215; app/commerce/pix_payment_repository.py:108–112.

Novo hash estável identifica sessão+external_reference+valor. No chamador normal, external_reference repete sessão. Trocar produto, variante ou endereço sem alterar total gera a mesma chave embora a versão confirmada do pedido seja outra. A criação reaproveita identidade do pagamento; o upsert aceita sobrescrever snapshot e versão da nova compra no mesmo pagamento. Uma revisão antiga pode ser paga e conciliada com conteúdo novo. Isso é uma lacuna específica da correção de F12, cuja antiga chave aleatória já foi substituída.

**Prova:** `test_same_total_different_order_reviews_reuse_payment_identity` captura chamadas a API mock: SKU-A e SKU-B têm chave idêntica e snapshots diferentes persistidos. O comportamento real de replay do provedor não foi exercitado; a colisão de identidade da aplicação é demonstrada.

**Remediação:** identidade da intenção de compra imutável incluindo versão confirmada, tenant e centavos canônicos; snapshot write-once do pagamento. Para renovar PIX expirado, nova tentativa persistida dentro da mesma intenção; não trocar snapshot de uma cobrança existente. Testar revisão de mesmo valor, pagamento tardio, timeout e retry.

### C4 — P1, PIX habilitado: falhas permanentes bloqueiam toda fila de conciliação

**Código:** app/commerce/pix_payment_repository.py:332–371.

SQL seleciona as primeiras N linhas failed/pending/processing por updated_at, e só após LIMIT remove `amount_mismatch` e outras falhas não recuperáveis. Dez falhas permanentes antigas com limit padrão 10 fazem toda execução retornar vazio, indefinidamente, mesmo existindo pagamentos pending mais novos. Essas linhas não são atualizadas e permanecem no início.

**Prova:** `test_nonretryable_front_page_starves_pending_rows` fornece página de dez falhas permanentes, confirma LIMIT no SQL sem filtro settlement_error e resultado vazio.

**Remediação:** elegibilidade e idade da lease devem ser predicados SQL antes de ORDER/LIMIT; estados terminais separados. Teste com banco descartável contendo N falhas definitivas + um pending para garantir progresso. Também usar claim/requeue com condição atômica de idade: `requeue_pix_settlement` em :373–392 aceita qualquer processing, sem conferir idade no UPDATE, possibilitando concorrência com outro trabalhador que acabou de assumir o item.

### C5 — P2: conciliação aceita pedido sem comprovação de sessão

**Código:** app/commerce/pix_settlement.py:112–127; contraponto TRAYadaptor/app/resources/orders.py:178–196.

`find_existing_tray_order` considera ausência de session_id equivalente à sessão solicitada e retorna primeiro ID. O próprio adaptador é mais rigoroso na recuperação interna: exige igualdade e um único candidato. Uma resposta parcial ou filtro não respeitado pode vincular pagamento a pedido indevido. Cenário condicional ao contrato da resposta; não foi comprovada resposta real sem session_id.

**Prova:** `test_reconciliation_accepts_order_without_matching_session`: um pedido só com ID `unrelated-order` é aceito para sessão `fake-cart`.

**Remediação:** exigir sessão explícita e única; consultar detalhe e validar identidade financeira/comercial se a listagem não fornecer evidência suficiente. Falha da consulta é resultado desconhecido e não equivale a ausência: hoje :120–121 devolve None em qualquer exceção e libera POST em :289, outra janela que merece teste de timeout pós-commit.

## Testes executados

- Agente: `python -m pytest tests/commerce tests/stories tests/security/test_remote_media.py -q` → **475 passaram, 1 falhou** em 9,06s.
- Falha: tests/commerce/test_commerce_integration.py:256, `test_broad_recommendation_with_budget_starts_retrieval`: busca e orçamento corretos, mas fake do compositor retorna frase genérica sem nome do produto e asserção espera nome. Trata-se de incompatibilidade demonstrada entre expectativa e composição; não é prova isolada de falha em produção. Deve esclarecer contrato mínimo da recomendação e atualizar mock/validador coerentemente.
- TRAYadaptor, diretório próprio: `python -m pytest tests/test_orders.py tests/test_carts.py tests/test_order_payments.py tests/test_order_contract_from_nsagent.py tests/test_internal_auth.py -q` → **154 passaram** em 4,33s.
- Cinco probes adicionais acima → **5 passaram** em 1,16s. Sem acesso a banco real.

## Inventário e limites reais da revisão

Leitura integral concentrada: pix_settlement.py, pix_payment_service.py, pix_payment_repository.py, pix_checkout_service.py, pix_webhook_api.py, tray_webhook_consumer.py, core/remote_media.py, channels/supabase_storage.py, channels/brevo_instagram_media.py, stories/story_media_retention.py, TRAYadaptor/app/resources/orders.py.

Leitura de trechos críticos e funções: commerce/cart_service.py, order_service.py (_current_order_facts, create_order e parsing), checkout_data_service.py (normalização), shipping_service.py (cotação), mercadopago_client.py (criação/valores), tray/tray_adapter_client.py (_request, carrinhos/pedidos), stories/instagram_story_media.py (armazenamento/validação), TRAYadaptor/app/resources/carts.py (mutação/reconciliação), normalizers/order.py (sessão), testes PIX e fixtures. Demais arquivos de commerce/tray/channels/stories foram inventariados, mas não se afirma leitura linha a linha de todos. Não afirmar certificação de segurança ou de produção.

Pontos positivos observados: agente não repete POST automaticamente no cliente HTTP; adaptador controla recuperação de pedidos/carrinhos; confirmação vincula hash dos fatos do pedido; PIX valida montantes antes do caminho principal; downloads agora restringem HTTPS/hosts/IP e bytes em streaming. Esses controles não eliminam as portas alternativas e falhas de recuperação documentadas.

Melhorias adicionais de engenharia a validar, sem contabilizar como novos incidentes: lease de settlement usa updated_at compartilhado com polling/webhooks (atualizações de status podem renovar artificialmente idade); mídia mantém risco documentado de resolução DNS diferente na conexão; áudio público não evidencia política de retenção neste módulo; StoryMediaStorage.exists retorna bool(path), não existência real, e get_private é stub já declarado. Priorizar provas dos cinco achados antes de ampliar escopo arquitetural.
