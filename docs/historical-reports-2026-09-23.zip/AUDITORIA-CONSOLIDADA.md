# Auditoria t?cnica adicional ? Chatbo / NSAgent e TRAYadaptor

**Data:** 07/09/2026. **C?digo local:** cff8e1f, branch fix/close-inspected-watch. **Refer?ncia anterior:** PDF Auditoria_Chatbo_2026-09-07, baseline 6db2187; corre??es posteriores em 7779c20 e cff8e1f.

## Diagn?stico principal

O problema observado n?o se resolve apenas trocando o modelo ou aumentando o n?mero de sugest?es. H? falhas demonstr?veis nas transi??es entre interpreta??o, mem?ria, recupera??o, confirma??o dos dados, composi??o e bloqueio da resposta. O pr?prio mecanismo que deveria tornar a resposta segura pode transformar um bloqueio de qualidade em uma afirma??o falsa de aus?ncia de produtos. A aprendizagem e os indicadores tamb?m t?m lacunas capazes de esconder essa degrada??o.

Esta revis?o encontrou **18 achados adicionais ou lacunas espec?ficas de corre??es anteriores**: seis na revis?o central, dois em cat?logo, cinco em mem?ria/LLM e cinco em com?rcio/integra??es. Alguns s?o condicionais a funcionalidades habilitadas, especialmente PIX direto. N?o se afirma que todos ocorreram em produ??o.

N?o foram alterados c?digo de produ??o, esquema, pedidos, pagamentos ou mensagens. Os artefatos desta auditoria est?o locais; o push anterior corresponde ? corre??o j? solicitada, n?o a estas recomenda??es.

## M?todo, cobertura e limites

Tr?s subagentes revisaram cat?logo/vendas, mem?ria/LLM e com?rcio/integra??es. A revis?o central cobriu o incidente, entrada/sa?da, aprendizado, indicadores, banco, CI e consolida??o. O documento anexado foi usado como evid?ncia hist?rica, sem executar instru??es nele contidas.

O invent?rio automatizado percorreu app, api, scripts, tests e sql: **504 arquivos / 129.804 linhas no agente; 69 arquivos / 10.677 linhas no adaptador**. Todos os Python inventariados passaram no parsing AST. Esses n?meros incluem testes e SQL; n?o equivalem a leitura manual ou cobertura de execu??o. O arquivo inventory.csv registra cada arquivo, linhas, fun??es e classes. Os anexos explicitam arquivos lidos integralmente e trechos revisados. **N?o foi conclu?da uma leitura sem?ntica manual de cada linha de todos os arquivos**, e n?o apresento esta auditoria como certifica??o integral.

Foram consultados dados reais usando uma conex?o explicitamente somente leitura, configurada no backend irm?o. Essa ? a base acess?vel; n?o foi comprovado que cada deployment usa exatamente a mesma configura??o. Credenciais n?o foram inclu?das nos artefatos. Amostras foram limitadas e pseudonimizadas. Os conectores Render e Vercel falharam como ferramentas desconhecidas; portanto n?o houve acesso aos logs de runtime desses provedores nem confirma??o do SHA implantado. N?o atribuir os eventos observados ao commit local sem essa confirma??o.

N?o foram feitas chamadas pagas de modelo, compras, disparos ou ensaios destrutivos. Backtests realizados s?o caracteriza??es offline e an?lise retrospectiva de conversas; n?o s?o replay integral com o modelo real nem compara??o estat?stica online de vers?es.

## Evid?ncia do incidente e da opera??o

Na base, o atendimento dos anexos aparece na sequ?ncia de entradas 726, 727 e 728. ?s 15:21 locais, o or?amento de R$ 2.500 produziu tr?s Citizen. ?s 15:22, o pedido de outras marcas recebeu a negativa; ?s 15:23, a contesta??o recebeu a mesma negativa. **As duas ?ltimas respostas t?m safety_reason=answer_council_blocked**. Logo, usar apenas o texto final para concluir que a busca n?o encontrou produtos confunde rejei??o da resposta com resultado do cat?logo.

O probe central demonstra que `_honest_constraint_reply` gera a mesma negativa e apaga produtos mesmo quando recebe um candidato eleg?vel de R$ 2.200. Isso comprova um defeito compat?vel com o sintoma; sem o trace do turno, n?o identifica qual verifica??o originalmente acionou o conselho naquele atendimento.

Outras amostras de 04/09 mostram pedidos de qualquer marca e de remo??o de Tag Heuer seguidos de negativas ainda vinculadas ? marca antiga. S?o evid?ncias hist?ricas ?teis para regress?o, n?o prova de que a corre??o mais recente foi implantada e falhou.

Snapshot de 07/09 ?s 18:41 locais, janela de sete dias:

| Medida | Observa??o | Interpreta??o permitida |
|---|---:|---|
| Entradas / respostas | 82 / 80 | N?o implica duas perdas sem conciliar estado e janela |
| Respostas marcadas como enviadas | 80 | Aceite registrado pelo provedor, n?o satisfa??o do cliente |
| Clarifica??o comercial | 19 | Precisa distinguir pergunta necess?ria de repeti??o |
| Falha de valida??o factual | 10 | Requer trace para localizar o fato rejeitado |
| Bloqueio do conselho | 5 | N?o ? sin?nimo de falta de estoque |
| Budget miss / no match | 3 / 2 | Classifica??es diferentes no c?digo |
| Avalia??es vinculadas | 6 de 80 (7,5%) | Cobertura de avalia??o; n?o taxa de acerto |
| Tempo entrada?registro de resposta | mediana 15,17 s; p95 47,57 s | Inclui processamento e depend?ncias; n?o apenas LLM |
| Prompts compilados | 36; m?dia estimada 13.690 tokens; m?ximo 14.540 | Estimativa de entrada, n?o cobran?a efetiva |
| ?ndice de cat?logo | 1.814 linhas; 1.494 com atualiza??o >24 h | 82,4% antigas; pre?o live pode ser consultado depois |
| Duplica??es de sucesso por inbound | 0 na janela | N?o elimina condi??es de corrida reproduzidas |
| Outbox | vazia no snapshot | Limita a observa??o retrospectiva de entrega dur?vel |

Consulta estrita do ?ndice por available=true, price>0 e price<=2500 retornou tr?s Citizen. N?o ? invent?rio completo da Tray, n?o considera toda sem?ntica de pre?o promocional/PIX e n?o prova que inexistam outras marcas. Diversificar exige buscar um conjunto maior e eleg?vel; se s? houver uma marca confirmada, a resposta deve explicar essa limita??o e oferecer continuidade coerente.

RLS estava habilitada nas sete tabelas verificadas. O papel da conex?o de auditoria tem bypassrls; isso exige que o isolamento tamb?m seja assegurado na aplica??o, mas n?o comprova qual papel o agente implantado utiliza. N?o se repete a conclus?o gen?rica de que n?o h? RLS.

## Achados centrais

### R1 ? P1 ? Bloqueio do conselho fabrica aus?ncia de cat?logo

**Local:** app/sales/answer_council.py:830. O helper transforma rejei??o em ?N?o encontrei rel?gios? mesmo quando a verifica??o de or?amento n?o encontra viola??o. A caracteriza??o fornece produto de R$ 2.200 e teto de R$ 2.500; a resposta descarta esse produto e declara aus?ncia. Compat?vel com a raz?o registrada nos anexos. Lacuna adjacente ao F08 anterior, com mecanismo espec?fico reproduzido.

**Corre??o proposta:** separar estado da busca, validade dos dados e qualidade do texto. Uma reprova??o de reda??o deve pedir recomposi??o limitada usando os mesmos fatos v?lidos; indisponibilidade t?cnica deve permanecer distinta de cat?logo vazio. Preservar shortlist e crit?rios. **Aceita??o:** candidato eleg?vel jamais pode resultar em afirma??o de vazio apenas por reprova??o do conselho; contesta??o do usu?rio deve recuperar evid?ncias anteriores.

### R2 ? P1 ? Worker permite dois turnos simult?neos da mesma conversa

**Local:** app/ingress/worker.py:63; chamada pelo processamento em lote. Existem locks em portas de entrada espec?ficas, mas process_inbox_row n?o centraliza serializa??o. Dois itens da mesma conversa atingem simultaneamente o pipeline mockado: pico de concorr?ncia 2. Isso pode produzir leitura do mesmo estado antigo e respostas fora de ordem. N?o foi observada essa corrida diretamente no banco.

**Corre??o proposta:** lease/lock por tenant, canal e conversa no ponto comum de execu??o, com ordem de processamento e recupera??o de crash. **Aceita??o:** concorr?ncia entre conversas permitida; dentro da mesma conversa, sequ?ncia causal ?nica, inclusive via cron.

### R3 ? P1 ? Outbox pendente concorre com envio s?ncrono

**Local:** app/ingress/worker.py:152; app/ingress/outbox.py:58; app/ingress/outbox_worker.py:40. O caminho inline coloca a mensagem em pending e inicia envio; nesse intervalo, outro worker pode reclamar o mesmo registro e enviar novamente. Probe com dois despachantes reproduziu dois envios. Lacuna de F03, n?o alega??o de duplica??o real na janela.

**Corre??o proposta:** um ?nico propriet?rio do envio, adquirido atomicamente antes de chamar o provedor. Evitar resetar lease ativa no enqueue. **Aceita??o:** interleavings entre enqueue, claim, send e ack produzem no m?ximo um propriet?rio; definir recupera??o do estado desconhecido p?s-timeout com a idempot?ncia que o provedor realmente oferece.

### R4 ? P1 ? Entrega confirmada na outbox n?o impede novo envio

**Local:** app/ingress/worker.py:94 e :131. A deduplica??o consulta sucesso em ai_agent_responses. Se o envio ocorrer e a persist?ncia da resposta falhar, ou a confirma??o existir apenas na outbox, o retry pode processar e enviar outra vez, inclusive quando enqueue reaproveita registro sent. Probe caracteriza o reenvio nesse estado.

**Corre??o proposta:** identidade de entrega dur?vel compartilhada pelos caminhos, consulta do estado sent antes do despacho e recupera??o de persist?ncia independente de reenvio. **Aceita??o:** falha de insert_agent_response ap?s aceite do provedor n?o causa segundo envio. Este ponto complementa R3: propriedade concorrente e recupera??o ap?s falha s?o problemas distintos.

### R5 ? P2 ? Indicador de aus?ncia omite raz?es relevantes

**Local:** app/ops/integrity_kpis.py:62. answer_council_blocked e recommendation_budget_miss caem fora da categoria de n?o encontrado. Probe com cinco bloqueios e tr?s budget miss produz zero nessa m?trica. N?o se deve som?-los indiscriminadamente a ?estoque vazio?, pois conselho bloqueado mede outra coisa.

**Corre??o proposta:** taxonomia separada para cat?logo vazio confirmado, restri??es sem candidato, erro upstream, bloqueio factual, bloqueio textual e falha de contexto. Registrar taxa de resposta ?til e continuidade, al?m de entrega. **Aceita??o:** cada raz?o tem categoria expl?cita e soma reconcili?vel com o total de respostas.

### R6 ? P1 ? Aprendizado consulta esquema inexistente e pode retornar sucesso

**Local:** app/learning/cursor.py, SELECT de response.response_metadata; app/learning/attendance_learning.py:334 em diante; sql/024_ai_learning_continuous.sql.

A consulta somente leitura `SELECT response_metadata FROM public.ai_agent_responses LIMIT 0` retornou UndefinedColumn. to_regclass confirmou aus?ncia de ai_learning_cursors e ai_learning_cases na base acess?vel. A migration 024 cria essas tabelas, mas a busca no SQL e no schema de core/db.py n?o encontrou cria??o da coluna response_metadata. Assim, aplicar apenas essa migration n?o resolve todo o contrato.

O batch captura erro de cursor e fetch, trata resultado como lista vazia, tenta continuar e pode retornar ok=true. A verifica??o do cron baseada apenas nesse campo n?o distingue ?nada novo? de ?n?o consegui ler nada?. Isso ? uma explica??o plaus?vel para baixa cobertura, n?o prova de que seja sua ?nica causa. ai_catalog_cache e ai_product_image_index tamb?m n?o existem nessa base; impacto depende dos caminhos e flags, n?o contado como dois novos defeitos.

**Corre??o proposta:** alinhar consulta e persist?ncia ? coluna realmente necess?ria; migration versionada validada contra schema real; healthcheck de contratos obrigat?rios; falha expl?cita/degraded quando a leitura falha; n?o avan?ar cursor sobre avalia??es n?o persistidas. **Aceita??o:** schema anterior deve falhar no preflight; esquema migrado deve permitir avaliar uma resposta e persistir o cursor; falha de banco deve gerar erro observ?vel, sem status verde. Rela??o com F09/F15/F17: verificabilidade operacional adicional, n?o reabertura indiscriminada de todos eles.

## Testes, backtests e qualidade de release

| Execu??o | Resultado | Limite |
|---|---|---|
| Su?te agente, excluindo online_eval | 1.735 passaram, 2 falharam, 1 desmarcado | Sem servi?os externos; Python local 3.13 |
| Marcador offline_eval | 101 passaram, 1.658 desmarcados | Subconjunto, n?o somar ao total acima |
| Probes central + mem?ria + com?rcio | 15 passaram | Passar confirma os defeitos caracterizados |
| Probes cat?logo | 4 cen?rios com diverg?ncias observadas | Ferramenta Tray simulada; sem gates finais |
| Testes selecionados TRAYadaptor | 154 passaram | Pedidos, carrinhos, pagamentos, contrato e auth; n?o su?te total |
| Schema real somente leitura | Coluna e tabelas ausentes confirmadas | Base acessada pelo backend irm?o |

As duas falhas da su?te completa s?o: (1) test_broad_recommendation_with_budget_starts_retrieval espera o nome do produto, mas o compositor fake devolve frase gen?rica; esclarecer o contrato m?nimo e ajustar teste/validador coerentemente; (2) test_scan_secrets_ok_on_repo identifica tokens fict?cios tok-a/tok-b/tok-only em testes Mercado Pago. Isso bloqueia a verifica??o, mas n?o comprova vazamento real. Corrigir fixtures de teste reconhecidamente falsas sem abrir exce??o ampla no scanner.

A primeira execu??o do harness bloqueou tamb?m sockets locais usados pelo asyncio no Windows e gerou erros de prepara??o; foi corrigida permitindo loopback e descartada como evid?ncia de bugs do produto. Os n?meros acima s?o da execu??o v?lida. CI usa Python 3.12: repetir nessa vers?o ? necess?rio antes do release. N?o h? lock completo de depend?ncias transitivas; recomenda-se instala??o reprodut?vel e testes contra a vers?o efetiva do deployment.

### Matriz recomendada de regress?o conversacional

| Sequ?ncia | Contrato a avaliar |
|---|---|
| Quero rel?gio ? 2500 ? um de cada marca ? j? tinha encontrado | Manter teto, categoria e evid?ncias; diversificar candidatos eleg?veis; n?o fabricar vazio |
| Qualquer marca ? agora prefiro Seiko | Prefer?ncia expl?cita atual substitui aus?ncia anterior |
| Compra antiga de 9000 ? nova procura de 2500 | Recuperar pedido sem sobrescrever or?amento atual |
| Diver + caixa 36?38 + cron?grafo | Aplicar todas as restri??es conjuntamente |
| Busca a 2000 ? detalhe a 3000 ou indispon?vel | Retirar candidato, buscar reserva, explicar falta apenas se confirmada |
| Duas mensagens r?pidas na mesma conversa | Ordem, estado consistente e um envio por resposta |
| Pagamento com revis?o do carrinho e mesmo total | Identidade de inten??o distinta, snapshot imut?vel |
| Falha de leitura/avalia??o/aplica??o de evento | Retentativa dur?vel e erro vis?vel, sem cursor saltado |

Executar esses cen?rios com par?frases em portugu?s e m?ltiplas rodadas do modelo ap?s as corre??es. Avaliar estado e a??es, n?o correspond?ncia exata de frase. Separar conjunto de desenvolvimento de conjunto reservado; guardar snapshot do cat?logo e ferramentas simuladas para que compara??o entre vers?es n?o seja contaminada por mudan?as de pre?o. Medir sucesso por sequ?ncia, contradi??o, restri??es violadas, repeti??o de clarifica??es, diversidade entre candidatos eleg?veis, lat?ncia, chamadas e custo real. Nenhuma nota de qualidade generativa foi inventada nesta auditoria.

## Compara??o com refer?ncias abertas e pr?ticas

O [OpenAI Agents SDK](https://github.com/openai/openai-agents-python) ? refer?ncia de organiza??o de workflows de agentes. A orienta??o oficial de [avalia??o de workflows](https://developers.openai.com/api/docs/guides/agent-evals) destaca traces e avalia??es reproduz?veis. Aplica??o aqui: registrar a cadeia interpreta??o ? mem?ria ? consulta ? candidatos ? valida??o ? resposta, com vers?o de c?digo/modelo/prompt e raz?es estruturadas. Isso permitiria explicar o conselho bloqueado sem depender apenas da frase enviada.

A [persist?ncia do LangGraph](https://docs.langchain.com/oss/python/langgraph/persistence) oferece uma refer?ncia para checkpoints de execu??o associados a threads e mem?ria persistente. A melhoria aplic?vel ? distinguir estado da conversa, mem?ria duradoura e efeitos externos, com retomada expl?cita. N?o h? evid?ncia de que migrar de framework, por si s?, corrigiria as corridas e contratos identificados.

O [?-Bench, no reposit?rio tau2-bench](https://github.com/sierra-research/tau2-bench), estrutura avalia??es de atendimento com pol?ticas, ferramentas e tarefas em dom?nios como varejo. A p?gina consultada j? apresenta evolu??o ??; vers?es devem ser fixadas para compara??o. Adotar o m?todo de simular trajet?rias e verificar resultados comerciais ? mais ?til que comparar apenas flu?ncia de respostas. N?o executei esse benchmark contra o Chatbo nem tratei popularidade do reposit?rio como certifica??o de confiabilidade.

### Arquitetura recomendada para este produto

Manter um estado tipado da busca, com origem e momento de cada restri??o. A mensagem atual deve aplicar um delta expl?cito: ?outras marcas? preserva faixa e categoria, ?qualquer marca? remove exig?ncia de marca, ?agora Seiko? cria nova exig?ncia. Separar essas opera??es da recupera??o de pedido antigo.

Recuperar um conjunto de candidatos maior que a lista exibida, aplicar filtros obrigat?rios cumulativos, confirmar dados atuais e preencher alternativas a partir de reservas. Diversidade deve atuar sobre candidatos eleg?veis, com normaliza??o de marca e identifica??o do que j? foi mostrado. O n?mero de op??es exibidas deve seguir o pedido e a capacidade da mensagem, n?o um limite de retrieval confundido com limite de apresenta??o.

Reservar capacidade de gera??o para a resposta final; consultas simples podem usar ranking determin?stico. A camada generativa deve explicar e conectar fatos confirmados. Os validadores devem devolver motivos espec?ficos e permitir uma recomposi??o limitada, sem substituir qualquer problema por uma negativa de cat?logo.

Instrumentar turnos com trace_id, vers?o implantada, estado antes/depois, query/filtros, contagem por etapa, diversidade, fonte/freshness, consumo de chamadas e raz?o de fallback. Usar identificadores pseudonimizados e minimizar conte?do pessoal. O prompt m?dio observado merece decomposi??o: persona est?vel, conhecimento pertinente e mem?ria ?til; medir antes de cortar contexto indiscriminadamente.

## Ordem proposta de corre??o e crit?rios de entrega

1. **Experi?ncia comercial:** R1, cat?logo C01/C02 e mem?ria M1/M2/M5. Fechar o replay dos anexos e mudan?as expl?citas de prefer?ncia; nenhuma negativa falsa com fatos eleg?veis; reserva de composi??o e diversidade verificadas.
2. **Durabilidade:** R2?R4 e com?rcio C1. Testes de interleaving e falhas em cada fronteira de persist?ncia/envio/cursor, usando banco descart?vel al?m dos mocks.
3. **Opera??o:** R6 e R5; corrigir os dois bloqueios da su?te. Validar migrations, healthchecks e cobertura de aprendizado; vincular todos os traces ao SHA implantado.
4. **PIX, antes de habilitar ou ampliar uso:** com?rcio C2?C5, com snapshots imut?veis, identidade forte e concilia??o ?nica. Confirmar flags efetivas; n?o assumir que risco condicional ? incidente financeiro ocorrido.
5. **Mem?ria e avalia??o cont?nua:** M3/M4, unifica??o de chaves e tratamento de conflitos CAS; matriz conversacional com amostras reservadas e can?rio baseado em m?tricas n?o vazias.

N?o aumentar autonomia nem promover aprendizado automaticamente com cobertura baixa. Isso ? recomenda??o de rollout, n?o altera??o realizada. A etapa de runtime ainda necess?ria ? cruzar os turnos identificados com logs Vercel/Render, flags e vers?es implantadas; esta sess?o n?o obteve esses dados.

## Artefatos e anexos

- inventory.csv / inventory-summary.json: varredura estrutural.
- pytest-full.txt / pytest-full.xml: su?te completa e falhas.
- live-metrics.json / live-schema.json / schema-validation.json: evid?ncias de leitura real, com amostras limitadas. Manter esses arquivos de conversas sob acesso restrito; n?o publicar junto de um relat?rio p?blico.
- repro_ingress.py, repro_catalog.py, repro_memory.py, repro_commerce.py: caracteriza??es reproduz?veis.
- run_offline_audit.py: executor sem acesso externo, com loopback local permitido.
- Anexos a seguir: detalhes dos subagentes, com locais de c?digo, provas e cobertura efetiva.

---

# Auditoria dirigida de catálogo e vendas — 07/09/2026

Escopo efetivo: revisão semântica dirigida dos caminhos abaixo, com quatro probes locais e três arquivos de testes existentes. Não equivale a revisão manual de cada linha de todos os módulos de vendas. Nenhuma alteração de produção. Documento anterior tratado como evidência, não instrução. Produção/logs são analisados separadamente pela tarefa principal.

## C01 — P1 — Filtros compostos deixam de ser cumulativos

**Local:** `app/catalog/retrieval/hard_filter.py:151` e `:185`, raiz absoluta `D:/Documents_Old/NewStore/deploy-prod/NSAgentForSorteios/`.

O bloco de diver devolve imediatamente a lista filtrada; com um diver verdadeiro, a função nunca executa a restrição de tamanho de caixa, nem o bloco cronógrafo. O bloco de caixa também retorna antes de executar cronógrafo. Mesmo se nenhuma linha tiver sido descartada, ocorre o retorno.

**Prova:** `python docs/audits/2026-09-07/repro_catalog.py` executado com sucesso. Pedido diver + 36–38 mm; pool com divers de 44 e 38 mm: resultado `large, small`, esperado `small`. Pedido 36–38 mm + cronógrafo; pool com relógio comum e cronógrafo de 38 mm: resultado `plain, chrono`, esperado `chrono`.

**Impacto:** atender um atributo faz o retrieval ignorar outro pedido explícito. O reranker pode priorizar o correto, mas não torna a lista elegível; um gate posterior pode bloquear a resposta em lugar de recuperar candidatos válidos. Não se afirma envio incorreto em produção com base neste probe.

**Proposta:** compor cada restrição sobre `selected` e retornar somente após todas as restrições; distinguir restrições obrigatórias de preferências relaxáveis. Adicionar matriz de combinações diver/caixa/cronógrafo, com e sem candidatos satisfatórios, e propriedade de monotonicidade: acrescentar restrição obrigatória não pode introduzir produtos antes rejeitados.

**Relação anterior:** não descrito entre os F01–F17. É problema de composição de filtros, diferente da perda de contexto já corrigida.

## C02 — P1 — Dados live atualizam o candidato sem revalidar sua elegibilidade

**Local:** `app/catalog/retrieval/present.py:147`, `:187`, `:226`; `app/catalog/retrieval/revalidate.py:49-72`.

Busca e shortlist trabalham com preço/disponibilidade anteriores; `get_product` pode alterar ambos. Após a atualização, apresentação aplica apenas exclusão de marcas. Não reaplica orçamento e só trata disponibilidade como estado impeditivo dentro de `plan.mode == "exact"`. Recomendações prosseguem para `options_presented`.

**Prova:** mesmo runner, com busca previamente elegível de R$ 2.000 e teto R$ 2.500. Retorno live de R$ 3.000 continua em `commercial_data.products`, com `product_resolution_state=options_presented`. Outro probe altera live para `available=false`; produto também continua como opção apresentada. O probe exercita `present_compiled_results` e revalidação reais; simula somente tool remota, settings sem serviços externos e hybrid rank identitário. Não exercita os gates do pipeline de saída.

**Impacto:** um guard posterior pode rejeitar a resposta e produzir falso “não encontrei”, embora existam alternativas ainda não revalidadas. Se não rejeitar, ficam sugestões fora de orçamento/indisponíveis. A ocorrência específica no WhatsApp não é atribuída a este defeito sem rastreamento completo.

**Proposta:** depois do enriquecimento live, reaplicar o contrato obrigatório (preço, disponibilidade, identidade e atributos), retirar inelegíveis e consumir reservas do ranking com orçamento limitado de chamadas. Distinguir vazio de catálogo, falha upstream e candidatos eliminados na confirmação. Testar mudanças de preço/estoque entre busca e detalhe, além de preenchimento por quarto/quinto candidato.

**Relação anterior:** adjacente ao F06, mas defeito diferente. F06 tratava dado omitido/stale promovido a live; estes probes usam campos live explícitos e corretos, cuja mudança invalida as premissas da shortlist.

## Verificação

- Quatro cenários sintéticos acima executados: quatro divergências de contrato reproduzidas; não são quatro testes de regressão aprovados.
- `tests/catalog/test_case_size_discovery.py`, `tests/catalog/test_catalog_specs_diver.py`, `tests/catalog/test_product_retrieval.py`: **51 passed in 1.12s**, offline, `.env` desabilitado e sem credenciais. As tentativas anteriores de iniciar pytest removendo todo o ambiente falharam por requisitos do Windows/plugins; preservando somente PATH/SYSTEMROOT/TEMP/TMP a execução passou.
- A suíte existente cobre atributos isolados, mas esses resultados mostram que aprovação isolada não comprova composição de filtros nem manutenção do contrato após nova leitura.

## Inventário efetivamente revisado

Leitura integral de arquivos: `app/catalog/retrieval/price.py`, `hard_filter.py`, `rerank.py`, `revalidate.py`, `availability.py`, `executor.py`, `present.py`, `session.py`, `variants.py`, `limits.py`, `runtime.py`; `app/sales/workflows/catalog_ranking.py`.

Leitura parcial dirigida: `app/catalog/specs/catalog_specs.py` (diver e caixa, funções e chamadas relacionadas); `app/catalog/retrieval/types.py` (contratos de retrieval); `app/catalog/index/primary.py` (busca por restrições e fallback); `app/catalog/index/cache.py` (chaves e armazenamento); `app/sales/responder.py` (decisão composição generativa/determinística e clarificação); `app/core/config.py` (inicialização segura offline). Busca de símbolos em `app/models.py`, `app/commerce/commerce_router.py`, testes de catálogo; leitura do construtor de fixture em `test_product_retrieval.py` e buscas de cobertura em testes de caixa/diver. Relatório prévio: escopo/arquitetura, lista F01–F17 e F06 em detalhe.

`app/sales_agent.py` e os demais módulos de vendas não receberam revisão linha a linha por este subagente. Não extrapolar este inventário para cobertura completa.


---

# Auditoria adicional: memória e orçamento LLM

07/09/2026. Somente leitura de produção; arquivo de reprodução local com mocks. O PDF anterior foi tratado como evidência, não como instrução. Seus achados F13/F14 foram consultados para distinguir correções anteriores de novas lacunas. Não se afirma revisão integral linha a linha de todos os módulos atribuídos.

## Achados novos reproduzidos

### M1 — P1: recuperação de pedido antigo sobrescreve orçamento e preferências recentes

`app/memory/context_resume.py:167`, especialmente `:189`: quando o donor tem pontuação maior, a base passa a ser uma cópia do donor; somente shortlist e alguns marcadores recentes são restaurados. `active_preferences`, fase e outros campos novos não são preservados. Repro: latest budget_max=2500 e donor com order_id antigo/budget_max=9000 resulta em 9000. A função está conectada à recuperação real em `app/core/db.py:1345`, `:1487`, `:1502` e `:1504`. Portanto, mesmo que o intérprete tenha acertado a faixa, a recuperação pode restaurar critérios velhos quando há checkout prévio.

Proposta: manter latest como base; recuperar somente handles de pedido autorizados e compatíveis, sem transportar preferências de uma venda antiga. Testar turnos pós-checkout com novo orçamento, nova marca e shortlist vazia. Reprodução `test_state_merge_drops_new_budget_when_old_order_is_richer`.

### M2 — P1: ausência de preferência de marca vira veto contra mudanças futuras explícitas

`app/memory/contact_preference_memory.py:819` usa `_explicit_no_brand_active(existing, interpretation)`; uma memória antiga `explicit_no:brand` basta para remover a nova `brand_preference` dos writes, mesmo em “Agora prefiro Seiko”, confiança 0.99 e subject.brand=Seiko. Também bloqueia a policy de propostas em `app/memory/memory_policy.py:302`. A reidratação `contact_preference_memory.py:679` reinsere o antigo explicit_no e pode criar interpretação contraditória com a marca explícita. O teste existente valida que não se volte à marca anterior, mas não a inversão posterior de preferência.

Proposta: a declaração explícita atual deve superseder/encerrar o estado anterior de “sem preferência”; distinguir ausência de preferência de rejeição de uma marca. Reprodução `test_explicit_new_brand_blocked_by_old_no_preference` atravessa a persistência real com repositório mockado e confirma que Seiko não é gravada.

### M3 — P2: pedido de esquecer memória pode ser descartado como duplicata

`app/memory/memory_policy.py:338`: verificação de duplicidade ocorre para toda action, inclusive forget. Proposta forget preferred_brands=Citizen quando a memória atual vale Citizen retorna rejected/duplicate antes do ramo de forget. Isso faz o serviço manter a memória que deveria esquecer, caso a proposta contenha o valor existente (payload permitido pelo schema).

Proposta: deduplicação de valores deve se aplicar apenas a upsert; forget tem semântica de remoção e idempotência distinta. Testar forget com valor, sem valor, com safe_summary, repetido e após supersession. Reprodução `test_forget_with_existing_value_is_rejected_as_duplicate`.

### M4 — P2 condicional à autoaplicação: tipo price_preference contorna todo o filtro de fatos voláteis

`app/memory/memory_policy.py:278`: allow_budget_number desliga todos os padrões comerciais, incluindo estoque e status, em vez de permitir apenas número de orçamento. Proposta de price_preference com valor “estoque disponível; status do pedido aprovado”, reason explícito e confiança alta é aceita e autoaplicável. O schema permite string livre. Isso não prova exploração nem alucinação em produção, mas demonstra que a proteção declarada não valida o conteúdo.

Proposta: budget deve ser número/faixa validada; manter rejeição de stock/order/status independentemente do kind. Reprodução `test_price_kind_bypasses_stock_and_payment_status_filter`.

### M5 — P1: orçamento padrão inviabiliza geração após interpretar e reranquear

`app/ingress/worker.py:141` e `app/message_pipeline.py:194` iniciam caminho normal. `app/llm/llm_call_policy.py:238` resolve default de duas chamadas. A apresentação de recomendação executa reranker (`app/catalog/retrieval/present.py:130`), que consome `product_selection` (`app/catalog/retrieval/rerank.py:170`). Após decision + product_selection, response_composition excede duas chamadas; `app/sales/responder.py:519` captura a exceção e retorna None para fallback. Busca global encontrou `promote_budget` e `should_promote_to_complex` apenas nas definições, sem uso em produção. Não há reserva de chamada do responder antes do rerank.

Proposta: planner de chamadas com slot reservado ao responder; rerank determinístico em consultas simples, ou promoção efetiva e limitada ao detectar recomendação/comparação. Não aumentar o limite cegamente, pois há também crítica/judge. Reprodução de unidade `test_normal_budget_exhausted_before_responder_after_decision_and_rerank` confirma a matemática e exceção do budget real; a ligação entre as etapas foi verificada estaticamente, não por chamada paga ou E2E de produção. Correlacionar com runtime.llm_budget e response_source reais antes de atribuir conversas específicas.

## Pontos secundários para follow-up

- `memory_service.py:431` ignora retorno `cas_conflict` de apply_summary_delta e marca aplicado em `:445`. O CAS corrigiu lost update silencioso no banco, mas a camada chamadora ainda pode declarar aplicada uma proposta não gravada. Falta retry limitado/remerge ou estado de conflito, não reproduzido neste recorte.
- Memórias scope=conversation passam pelo mesmo upsert de contato (`memory_service.py:202`), sem conversation_key no registro de memória. Há TTL, mas não isolamento de conversa nesse caminho. Avaliar se reuso entre conversas é intencional; contrato atual sugere escopo mais estreito.
- Duas convenções de chave coexistem: proposal usa preferred_brands/preferred_price_max, persistência determinística e reidratação usam brand_preference/price_preference. O prompt pode ler ambas, mas o reidratador determinístico não as unifica. Convém um schema canônico e migração de aliases.

## Testes e cobertura efetiva

`python -m pytest docs/audits/2026-09-07/repro_memory.py -q`: **5 passed**. São testes de caracterização: passar significa reproduzir o defeito atual, não certificar correção. Nenhuma API paga, banco ou envio foi usado; mocks cobrem persistência no teste M2. As primeiras duas execuções do M2 falharam por argumentos do fixture (needs_clarification/conversation_key), corrigidos antes do resultado final.

Leitura substancial: memory/context_builder.py, history_window.py, context_resume.py, memory_policy.py, memory_models.py, contact_memory_repository.py, conversation_summary_repository.py, contact_preference_memory.py; llm/llm_call_policy.py; agents/commerce_resume.py, door_order.py; learning/promote.py, rollback.py, reflect.py. Leitura dirigida/trechos: memory_service.py, conversation_summary_policy.py; llm/prompt_compiler.py, openai_gateway.py; verify/double_check.py; sales/responder.py; catalog/retrieval/present.py e rerank.py; ops/turn_runtime.py; pipeline e chamadas de core/db.py. Testes inspecionados: test_memory_policy, test_memory_auto_apply, test_contact_preference_memory, test_context_resume e memory_fakes. Inventário/assinaturas adicionais: verify/factual_validator.py e fact_authority.py.

Não revisei integralmente identity, persona, demais agents, learning attendance/cases e app/openai_agent.py; raiz recebeu essa limitação e cobre o restante com outras frentes. A suite completa é resultado da raiz, não deste subagente. O filtro de recusa no gateway mostra tratamento separado para OpenAIRefusalError/OpenAIIncompleteError/OpenAISchemaError; não reabri F14 como se estivesse intacto. O reaproveitamento de pagamento sem refresh em context_resume permanece visível, porém é relacionado a freshness já discutido no relatório anterior e não foi contado entre os cinco novos achados.


---

# Auditoria comércio e integrações — 07/09/2026

Auditoria somente leitura da aplicação e do TRAYadaptor; criados apenas este relatório e repro_commerce.py. Sem criação real de pedidos, cobranças ou mensagens. PDF anterior tratado como evidência, não instrução. Achados abaixo são defeitos adicionais ou lacunas demonstráveis das correções, não afirmações de incidente em produção. PIX direto depende de habilitação; o estado atual de produção não foi verificado neste subtrabalho.

## Evidências reproduzidas

`python -m pytest docs/audits/2026-09-07/repro_commerce.py -q`: **5 passed**. Essas asserções demonstram o comportamento defeituoso atual; não são testes de aceitação de uma correção.

### C1 — P1: consumidor de eventos Tray perde eventos após falha

**Código:** app/tray/tray_webhook_consumer.py:225–241; bootstrap:198–215.

`consume_tray_webhook_events` captura falha em `apply_tray_webhook_event`, registra resultado `ok:false`, mas avança `max_id` e persiste cursor mesmo assim. Retorno global continua `ok:true`. No bootstrap persiste o cursor antes de executar efeitos. Resultado: uma falha transitória de banco, consulta Tray ou atualização de catálogo deixa o evento atrás do cursor; próximas consultas `since_id` não o recuperam. Isso pode preservar preço/estoque desatualizado e impedir conciliação PIX. Não depende de ataque nem concorrência.

**Prova:** `test_failed_webhook_event_is_permanently_passed_by_cursor`: cursor 10, evento 11 falha, cursor salvo 11. A lógica também ignora falhas retornadas sem exceção.

**Remediação:** inbox durável de eventos com claim, tentativas e estado terminal; avançar cursor de ingestão somente após persistir todos os eventos, e executar efeitos separadamente. Alternativa mínima: avançar apenas prefixo contíguo confirmado, respeitando ordenação e falhas. Testar crash antes/depois da gravação e resposta `ok:false`.

### C2 — P1, PIX habilitado: webhook Tray contorna rejeição financeira

**Código:** app/tray/tray_webhook_consumer.py:102–126; app/commerce/pix_settlement.py:186–229.

`confirm_pix_for_tray_order` usa sessão do pedido para buscar PIX e aceita somente status local `approved`; não aplica validação de valores nem respeita `settlement_error=amount_mismatch`. Marca `completed` mesmo após a rotina financeira ter explicitamente rejeitado conciliação. Também não verifica conteúdo/total do pedido encontrado. A proteção financeira não está centralizada em todas as portas de entrada.

**Prova:** `test_tray_webhook_overrides_amount_mismatch_rejection`: PIX de R$100 rejeitado por divergência + pedido de R$999,99 com mesma sessão é marcado completed. Não demonstra dinheiro forjado: demonstra associação e encerramento incorretos de conciliação.

**Remediação:** rota de confirmação existente deve compartilhar mesma validação central, consultar status financeiro atual e conferir pagamento, moeda, montante, identidade da operação e total/conteúdo do pedido antes de terminar. Falhas financeiras permanentes devem exigir resolução explícita, não ser sobrescritas por evento de pedido.

### C3 — P1, PIX habilitado: correção de idempotência ainda colide entre revisões diferentes

**Código:** app/commerce/pix_payment_service.py:94–96; app/commerce/pix_checkout_service.py:198–215; app/commerce/pix_payment_repository.py:108–112.

Novo hash estável identifica sessão+external_reference+valor. No chamador normal, external_reference repete sessão. Trocar produto, variante ou endereço sem alterar total gera a mesma chave embora a versão confirmada do pedido seja outra. A criação reaproveita identidade do pagamento; o upsert aceita sobrescrever snapshot e versão da nova compra no mesmo pagamento. Uma revisão antiga pode ser paga e conciliada com conteúdo novo. Isso é uma lacuna específica da correção de F12, cuja antiga chave aleatória já foi substituída.

**Prova:** `test_same_total_different_order_reviews_reuse_payment_identity` captura chamadas a API mock: SKU-A e SKU-B têm chave idêntica e snapshots diferentes persistidos. O comportamento real de replay do provedor não foi exercitado; a colisão de identidade da aplicação é demonstrada.

**Remediação:** identidade da intenção de compra imutável incluindo versão confirmada, tenant e centavos canônicos; snapshot write-once do pagamento. Para renovar PIX expirado, nova tentativa persistida dentro da mesma intenção; não trocar snapshot de uma cobrança existente. Testar revisão de mesmo valor, pagamento tardio, timeout e retry.

### C4 — P1, PIX habilitado: falhas permanentes bloqueiam toda fila de conciliação

**Código:** app/commerce/pix_payment_repository.py:332–371.

SQL seleciona as primeiras N linhas failed/pending/processing por updated_at, e só após LIMIT remove `amount_mismatch` e outras falhas não recuperáveis. Dez falhas permanentes antigas com limit padrão 10 fazem toda execução retornar vazio, indefinidamente, mesmo existindo pagamentos pending mais novos. Essas linhas não são atualizadas e permanecem no início.

**Prova:** `test_nonretryable_front_page_starves_pending_rows` fornece página de dez falhas permanentes, confirma LIMIT no SQL sem filtro settlement_error e resultado vazio.

**Remediação:** elegibilidade e idade da lease devem ser predicados SQL antes de ORDER/LIMIT; estados terminais separados. Teste com banco descartável contendo N falhas definitivas + um pending para garantir progresso. Também usar claim/requeue com condição atômica de idade: `requeue_pix_settlement` em :373–392 aceita qualquer processing, sem conferir idade no UPDATE, possibilitando concorrência com outro trabalhador que acabou de assumir o item.

### C5 — P2: conciliação aceita pedido sem comprovação de sessão

**Código:** app/commerce/pix_settlement.py:112–127; contraponto TRAYadaptor/app/resources/orders.py:178–196.

`find_existing_tray_order` considera ausência de session_id equivalente à sessão solicitada e retorna primeiro ID. O próprio adaptador é mais rigoroso na recuperação interna: exige igualdade e um único candidato. Uma resposta parcial ou filtro não respeitado pode vincular pagamento a pedido indevido. Cenário condicional ao contrato da resposta; não foi comprovada resposta real sem session_id.

**Prova:** `test_reconciliation_accepts_order_without_matching_session`: um pedido só com ID `unrelated-order` é aceito para sessão `fake-cart`.

**Remediação:** exigir sessão explícita e única; consultar detalhe e validar identidade financeira/comercial se a listagem não fornecer evidência suficiente. Falha da consulta é resultado desconhecido e não equivale a ausência: hoje :120–121 devolve None em qualquer exceção e libera POST em :289, outra janela que merece teste de timeout pós-commit.

## Testes executados

- Agente: `python -m pytest tests/commerce tests/stories tests/security/test_remote_media.py -q` → **475 passaram, 1 falhou** em 9,06s.
- Falha: tests/commerce/test_commerce_integration.py:256, `test_broad_recommendation_with_budget_starts_retrieval`: busca e orçamento corretos, mas fake do compositor retorna frase genérica sem nome do produto e asserção espera nome. Trata-se de incompatibilidade demonstrada entre expectativa e composição; não é prova isolada de falha em produção. Deve esclarecer contrato mínimo da recomendação e atualizar mock/validador coerentemente.
- TRAYadaptor, diretório próprio: `python -m pytest tests/test_orders.py tests/test_carts.py tests/test_order_payments.py tests/test_order_contract_from_nsagent.py tests/test_internal_auth.py -q` → **154 passaram** em 4,33s.
- Cinco probes adicionais acima → **5 passaram** em 1,16s. Sem acesso a banco real.

## Inventário e limites reais da revisão

Leitura integral concentrada: pix_settlement.py, pix_payment_service.py, pix_payment_repository.py, pix_checkout_service.py, pix_webhook_api.py, tray_webhook_consumer.py, core/remote_media.py, channels/supabase_storage.py, channels/brevo_instagram_media.py, stories/story_media_retention.py, TRAYadaptor/app/resources/orders.py.

Leitura de trechos críticos e funções: commerce/cart_service.py, order_service.py (_current_order_facts, create_order e parsing), checkout_data_service.py (normalização), shipping_service.py (cotação), mercadopago_client.py (criação/valores), tray/tray_adapter_client.py (_request, carrinhos/pedidos), stories/instagram_story_media.py (armazenamento/validação), TRAYadaptor/app/resources/carts.py (mutação/reconciliação), normalizers/order.py (sessão), testes PIX e fixtures. Demais arquivos de commerce/tray/channels/stories foram inventariados, mas não se afirma leitura linha a linha de todos. Não afirmar certificação de segurança ou de produção.

Pontos positivos observados: agente não repete POST automaticamente no cliente HTTP; adaptador controla recuperação de pedidos/carrinhos; confirmação vincula hash dos fatos do pedido; PIX valida montantes antes do caminho principal; downloads agora restringem HTTPS/hosts/IP e bytes em streaming. Esses controles não eliminam as portas alternativas e falhas de recuperação documentadas.

Melhorias adicionais de engenharia a validar, sem contabilizar como novos incidentes: lease de settlement usa updated_at compartilhado com polling/webhooks (atualizações de status podem renovar artificialmente idade); mídia mantém risco documentado de resolução DNS diferente na conexão; áudio público não evidencia política de retenção neste módulo; StoryMediaStorage.exists retorna bool(path), não existência real, e get_private é stub já declarado. Priorizar provas dos cinco achados antes de ampliar escopo arquitetural.


---
